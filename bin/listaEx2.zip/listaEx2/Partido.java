package listaEx2;

public class Partido {

	private String nome;
	private String ideologia;
	private String sigla;
	int numero;

	public Partido(String nome, String ideologia, String sigla, int numero) {

		this.nome = nome;
		this.ideologia = ideologia;
		this.sigla = sigla;
		this.numero = numero;
	}

	public String getNome() {
		return nome;
	}

	public String getIdeologia() {
		return ideologia;
	}

	public String getSigla() {
		return sigla;
	}

	public int getNumero() {
		return numero;
	}
	
	
}
